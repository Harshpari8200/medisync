import { DoctorDashboardView } from "../../../modules/doctor/views/dashboard-view";


export default function DoctorDashboard() {
  return <DoctorDashboardView />
}

