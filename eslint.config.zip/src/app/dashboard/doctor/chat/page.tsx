
import { ChatInterface } from '@/modules/chat/views/chat-doctor-view'
import React from 'react'

const ChatPage = () => {
    return (
        <ChatInterface />
    )
}

export default ChatPage