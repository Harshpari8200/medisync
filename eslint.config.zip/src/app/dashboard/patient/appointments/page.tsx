import BookAppointmentPage from '@/modules/patient/ui/components/book-appointment'
import React from 'react'

const Page = () => {
    return (
        <>
            <BookAppointmentPage />
        </>
    )
}

export default Page