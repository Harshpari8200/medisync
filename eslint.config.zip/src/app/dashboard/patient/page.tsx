import { PatientDashboardView } from "@/modules/patient/views/patien-dashboard";

export default function PatientDashboard() {
  return <PatientDashboardView />
}

